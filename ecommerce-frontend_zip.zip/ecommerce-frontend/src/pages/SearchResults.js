// src/pages/SearchResults.js
import React, { useEffect, useState } from "react";
import { useLocation, Link } from "react-router-dom";

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

function SearchResults() {
  const query = useQuery();
  const searchTerm = query.get("q") || "";
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!searchTerm) return;

    setLoading(true);
    setError(null);

    fetch(`http://127.0.0.1:8000/api/search/?q=${encodeURIComponent(searchTerm)}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch results");
        return res.json();
      })
      .then((data) => setResults(data))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [searchTerm]);

  return (
    <div className="container mt-4">
      <h4 className="mb-3">
        Search Results for: <span className="text-primary">{searchTerm}</span>
      </h4>

      {loading && <p>Loading results...</p>}
      {error && <p className="text-danger">{error}</p>}

      {!loading && !error && results.length === 0 && (
        <p>No products found.</p>
      )}

      <div className="row">
        {results.map((product) => (
          <div className="col-md-3 mb-4" key={product.pdt_id}>
            <div className="card shadow-sm h-100">
              <div className="card-body text-center">
                <h6 className="card-title">{product.pdt_name}</h6>
                <p className="text-muted mb-1">
                  ₹{product.pdt_dis_price || product.pdt_mrp}
                </p>
                <Link
                  to={`/product/${product.pdt_id}`}
                  className="btn btn-sm btn-outline-primary"
                >
                  View Details
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default SearchResults;
