from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Category, Product

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'password']

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password']
        )
        return user

class ProductSerializer(serializers.ModelSerializer):
    ct_id = serializers.IntegerField(source="ct.ct_id", read_only=True)
    class Meta:
        model = Product
        fields = ['pdt_id', 'pdt_name', 'pdt_mrp', 'pdt_dis_price', 'pdt_qty', 'ct_id']


class CategorySerializer(serializers.ModelSerializer):
    products_count = serializers.IntegerField(source='products.count', read_only=True)
    class Meta:
        model = Category
        fields = ['ct_id', 'ct_name', 'ct_description', 'ct_date', 'products_count']
